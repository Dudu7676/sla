window.onload = function() {
  alert("Bem vindo ao Projeto Final!");
};

const imagem = document.getElementById('logo');

imagem.addEventListener('click', function() {
  alert('Projeto Final');
});
